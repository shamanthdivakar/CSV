def add(x,y):
    add=x+y
    print("sum=",add)
def sub(x,y):
    sub=x-y
    print("sub=",sub)
def mul(x,y):
    mul=x*y
    print("mul=",mul)
def div(x,y):
    div=x/y
    print("div=",div)
